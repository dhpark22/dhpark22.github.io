function [M, S, err, time] = rpca_gd(Y, M0, S0, r, alpha_col, alpha_row, params)
% =========================================================================
% 
% Robust PCA via Gradient Descent
% 
% Y : A matrix to be decomposed into a low-rank matrix M and a sparse
% matrix S
% r : Rank of M
% alpha_col : Max sparsity over the columns of S
% alpha_row : Max sparsity over the row of S
% params : parameters for the algorithm
%   incoh : Incoherence of M
%   gamma : thresholding parameter (defulat 1)
%   step_const : Constant for step size (default .5)
%   max_iter : Maximum number of iterations
%   eps : Desired Frobenius norm error (default 1e-3) 
%   tol : tolerance parameter (default 1e-3)
%
% =========================================================================

% Default parameter settings
gamma      = 1;
incoh      = 10;
step_const = .5;
max_iter   = 100;
eps        = 1e-5;
tol        = 1e-3;
do_project = 1;

if isfield(params,'gamma')      gamma = params.gamma; end
if isfield(params,'incoh')      incoh = params.incoh; end
if isfield(params,'step_const') step_const = params.step_const; end
if isfield(params,'max_iter')   max_iter = params.max_iter; end
if isfield(params,'eps')        eps = params.eps; end
if isfield(params,'tol')        tol= params.tol; end
if isfield(params,'do_project') do_project = params.do_project; end

% libraries
addpath PROPACK;
addpath MinMaxSelection;

% Setting up
err  = zeros(1,max_iter);
time = zeros(1,max_iter);

Ynormfro = norm(Y,'fro');

[d1, d2] = size(Y);

%% Phase I: Initialization
tic; t = 1;

% Initial thresholding
fprintf('Initial thresholding %f \n', toc);

Yabs = abs(Y);

% taking top Kcol elements for each column of X
kcol = floor(alpha_col * d1);
%     	[~,Jcol] = sort(Eabs,1,'descend'); Jcol = Jcol(1:kcol,:);
[~,Jcol] = maxk(Yabs,kcol,1,'sorting',false);   
Icol = sub2ind([d1 d2], Jcol, repmat(1:d2,kcol,1));
Scol = zeros(d1,d2);
Scol(Icol) = Y(Icol);
 
% taking top Krow elements for each row of X (from Scol)
krow = floor(alpha_row * d2);
%   [~,Jrow] = sort(Eabs',1,'descend'); Jrow = Jrow(1:krow,:);
[~,Jrow] = maxk(Yabs',krow,1,'sorting',false);
Irow = sub2ind([d1 d2], repmat((1:d1)',1,krow), Jrow');
S = zeros(d1,d2);
S(Irow) = Scol(Irow);
	
	thresh = lansvd(Y,1,'L')*incoh*r/sqrt(d1*d2);
	T = min(thresh, max(-thresh, Y));
	S = Y-T;
  S = S.*(abs(S)>1e-7);

% Initial factorization
fprintf('Initial SVD %f \n', toc);

[U,Sig,V] = lansvd((Y-S),r,'L');
U = U(:,1:r) * sqrt(Sig(1:r,1:r));
V = V(:,1:r) * sqrt(Sig(1:r,1:r));

% Projection
if do_project
    fprintf('Projection %f \n', toc);
    const1 = sqrt(4*incoh*r/d1)*Sig(1,1);
    const2 = sqrt(4*incoh*r/d2)*Sig(1,1);
    U = U .* repmat(min(ones(d1,1),const1./sqrt(sum(U.^2,2))),1,r);
    V = V .* repmat(min(ones(d2,1),const2./sqrt(sum(V.^2,2))),1,r);
end

M = U * V';

% Compute the initial error
err(t)  = norm(Y-M-S, 'fro');
time(t) = toc;


%% Phase II: Gradient Descent
steplength = step_const / Sig(1,1);
kcol = floor(gamma * alpha_col * d1);
krow = floor(gamma * alpha_row * d2);

I1 = repmat(1:d2,kcol,1);
I2 = repmat((1:d1)',1,krow);

fprintf('Begin Gradient descent\n');
converged = 0;
while ~converged    
    fprintf('Iter no. %d err %e time %f \n', t, err(t), time(t));
		%fprintf('%d %d %d\n', nnz(S), nnz(S0), numel(intersect(find(S),find(S0))));
		t = t + 1;

    %% Thresholding for S
    E = Y - M;
    Eabs = abs(E);

    % taking top Kcol elements for each column of X
%     	[~,Jcol] = sort(Eabs,1,'descend'); Jcol = Jcol(1:Kcol,:);
    [~,Jcol] = maxk(Eabs,kcol,1,'sorting',false);   
    Icol = sub2ind([d1 d2], Jcol, I1);
    Scol = zeros(d1,d2);
    Scol(Icol) = E(Icol);
    
    % taking top Krow elements for each row of X (from Scol)
%     	[~,Jrow] = sort(Eabs',1,'descend'); Jrow = Jrow(1:Krow,:);
    [~,Jrow] = maxk(Eabs',krow,1,'sorting',false);
    Irow = sub2ind([d1 d2], I2, Jrow');
    S = zeros(d1,d2);
    S(Irow) = Scol(Irow);
    
	%% Gradient Descent for U and V
    G = S - E;
    Unew = U - steplength * (G * V) - steplength/2*U*(U'*U-V'*V);
    Vnew = V - steplength * (U' * G)' - steplength/2*V*(V'*V-U'*U);;

	% Projection
    if do_project
        Unew = Unew .* repmat(min(ones(d1,1),const1./sqrt(sum(Unew.^2,2))),1,r);
        Vnew = Vnew .* repmat(min(ones(d2,1),const2./sqrt(sum(Vnew.^2,2))),1,r);
    end
	
    U = Unew;
    V = Vnew;
    M = U * V';

    % Compute error
    err(t)  = norm(Y-M-S, 'fro');
    time(t) = toc;
    
    % Convergence check
    if (t >= max_iter) converged = 1; end
    if (err(t)/Ynormfro <= eps) converged = 1; end
    if ((err(t-1)-err(t))/err(t) <= tol) converged = 1; end
end

end
