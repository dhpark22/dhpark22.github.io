% =========================================================================
% 
% Robust PCA on synthetic data
% 
% =========================================================================
clear all; close all; clc;

d1 = 5000; % matrix size
d2 = 5000;

n_settings = 15;      % # of different settings
vec_alpha  = [.10 .10 .10 .10 .10 .05 .10 .15 .20 .25 .10 .10 .10 .10 .10];  % sparsity of S* (expected)
vec_r      = [ 10  20  50 100 200  20  20  20  20  20  20  20  20  20  20];  % rank of M*
vec_mu     = [  1   1   1   1   1   1   1   1   1   1   1 1.5   2 2.5   3];  % incoherence

MAX_ITER = 500;      % max number of iterations
n_runs = 5;

n_algo = 3;          % # of algorithms
err = zeros(n_settings, MAX_ITER, n_algo);
tim = zeros(n_settings, MAX_ITER, n_algo);

elp = zeros(n_settings, n_runs, n_algo);

for i_run = 1:n_runs
for i = [10 5 9 4 8 3 7 2 6 1]
% Get parameters
alpha = vec_alpha(i);
r     = vec_r(i);
mu    = vec_mu(i);

% Generate a low-rank matrix M*
U = zeros(d1,r);
I = randperm(d1);
U(I(1:floor(d1/mu)),:) = randn(floor(d1/mu),r)/sqrt(d1/mu);

V = zeros(d2,r);
I = randperm(d2);
V(I(1:floor(d2/mu)),:) = randn(floor(d2/mu),r)/sqrt(d2/mu);

M0 = U * V';

[U0,Sig0,V0] = svds(M0,r);
incoh = max([sum(U0.^2,2)/r*d1; sum(V0.^2,2)/r*d2]);

% Generate a sparse matrix S*
S0 = zeros(d1,d2);
supp = find(rand(d1,d2)<=alpha);
S0(supp) = (r/sqrt(d1*d2)) * (rand(length(supp),1)*.5+.5) .* sign(randn(length(supp),1)); 

% Combine the two matrices
Y = M0 + S0;

% Start decomposing
fprintf('%d x %d, sparsity %f (actual %f), rank %d, incoherence %f\n', d1, d2, alpha, length(supp)/d1/d2, r, incoh);

lambda = 1/sqrt(d1);

% RPCA via GD (ours)
tic;
i_method = 1;
K = max([sum(abs(sign(S0)),1) sum(abs(sign(S0)),2)']);
alpha_col = K/d1;
alpha_row = K/d2;
params.gamma = 1;
params.incoh = incoh;
params.step_const = .5;
params.max_iter = MAX_ITER;
params.eps = 1e-5;
params.tol = -1;   % no tolerance. we stop only when ||Y-M-S||_F <= eps or iter >= max_iter
[M, S, err_this, tim_this] = rpca_gd(Y, M0, S0, r, alpha_col, alpha_row, params);
elp(i,i_run,i_method) = toc;
rec(i,i_run,i_method) = norm(M-M0,'fro');

fprintf('Finished : error %e, time %f sec \n', norm(Y-M-S,'fro'), elp(i,i_run,i_method));

if (i_run == 1)
	err(i,1:length(err_this),i_method) = err_this;
	tim(i,1:length(err_this),i_method) = tim_this(1:length(err_this));
end

% AltProj (Netrapalli et al.) - Original version in the paper
tic;
i_method = 2;
EPS = 1e-5;
EPS_S = 1e-5;
[M, S, ~, err_this, tim_this] = ncrpca(Y, r, EPS, MAX_ITER, EPS_S, sqrt(incoh));
elp(i,i_run,i_method) = toc;
rec(i,i_run,i_method) = norm(M-M0,'fro');

fprintf('Finished : error %e, time %f sec \n', norm(Y-M-S,'fro'), elp(i,i_run,i_method));

if (i_run == 1)
	err(i,1:length(err_this),i_method) = err_this;
  tim(i,1:length(err_this),i_method) = tim_this(1:length(err_this));
end

% convex relaxation
tic;
i_method = 3;
%[M, S, ~, err_this, tim_this] = inexact_alm_rpca(Y, 1/sqrt(d1), 1e-5, MAX_ITER);
%elp(i,i_run,i_method) = toc;
%rec(i,i_run,i_method) = norm(M-M0,'fro');

%fprintf('Finished : error %e, time %f sec \n', norm(Y-M-S,'fro'), elp(i,i_run,i_method));

%if (i_run == 1)
%	err(i,1:length(err_this),i_method) = err_this;
%  tim(i,1:length(err_this),i_method) = tim_this(1:length(err_this));
%end

elp
rec

end

if (i_run == 1)
	save('result_temp.mat','err','tim','elp','rec');
end

end

save('result_gamma1_step0_5_new.mat','err','tim','elp','rec');

elptime = mean(elp,2);

figure;
semilogy(tim(2,:,1),err(2,:,1),'b-o'); hold on; grid on;
semilogy(tim(2,:,3),err(2,:,2),'r-^'); 
semilogy(tim(2,:,4),err(2,:,3),'k-v'); 

figure;
plot([10 20 50 100 200], elptime(1:5,:,1), 'b-o'); hold on; grid on;
plot([10 20 50 100 200], elptime(1:5,:,2), 'r-^');
plot([10 20 50 100 200], elptime(1:5,:,3), 'k-v');

figure;
plot(.05:.05:.25, elptime(6:10,:,1), 'b-o'); hold on; grid on;
plot(.05:.05:.25, elptime(6:10,:,2), 'r-^');
plot(.05:.05:.25, elptime(6:10,:,3), 'k-v');

figure;
plot(1:.5:3, elptime(11:15,:,1), 'b-o'); hold on; grid on;
plot(1:.5:3, elptime(11:15,:,2), 'r-^');
plot(1:.5:3, elptime(11:15,:,3), 'k-v');

